# 🏄‍♂️ surf_scrap

`surf_scrap` est une bibliothèque Python légère conçue pour extraire facilement les données de prévisions météo du site **Surf-Report.com**. 

Elle permet de récupérer les informations sur la taille des vagues, la vitesse du vent et son orientation pour n'importe quel spot répertorié, et de les sauvegarder directement dans un fichier CSV.

## 🚀 Installation

Si vous avez le dossier du projet, installez-le localement via le terminal :
```bash
pip install . 
pip install surf_scrap
```
## 🛠 Utilisation

La bibliothèque propose une fonction unique et simple : `scrape_surf_report`. Elle permet de choisir n'importe quel spot de surf-report.com et de sauvegarder les résultats où vous le souhaitez.

```python
from surf_scrap import scrape_surf_report
```
# URL du spot (ex: Carcans ou Moliets)
url = "https://www.surf-report.com/meteo-surf/carcans-plage-s1013.html"

# Emplacement personnalisé pour le fichier CSV
destination = "data_surf/data_surf.csv"

# Lancement de la fonction
scrape_surf_report(url, destination)

## 📊 Données extraites
Le package extrait les informations essentielles pour chaque créneau horaire :

Day : Le jour de la semaine.

Hour : L'heure de la prévision.

Waves_size : La hauteur des vagues (ex: 1m20).

Wind_speed : La force du vent (ex: 15km/h).

Wind_direction : L'orientation (ex: Offshore / Side-shore).

Pour mettre ces sections dans ton fichier README.md, il te suffit d'ouvrir ton fichier avec un éditeur de texte (comme VS Code, Notepad++, ou même le Bloc-notes) et de copier-coller le texte brut.

